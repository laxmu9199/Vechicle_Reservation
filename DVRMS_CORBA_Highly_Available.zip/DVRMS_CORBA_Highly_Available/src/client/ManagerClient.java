package client;

import idl.DVRMS.*;
import org.omg.CORBA.*;
import org.omg.CosNaming.*;
import org.omg.CosNaming.NamingContextExtHelper;

import java.util.Scanner;

public class ManagerClient {

    public static void main(String[] args) {

        try {

            ORB orb = ORB.init(args, null);

            org.omg.CORBA.Object objRef =
                    orb.resolve_initial_references("NameService");

            NamingContextExt ncRef =
                    NamingContextExtHelper.narrow(objRef);

            Scanner sc = new Scanner(System.in);

            // ================= LOGIN ONCE =================
            String managerID;

            while (true) {
                System.out.print("Enter Manager ID: ");
                managerID = sc.nextLine().toUpperCase();

                if (!InputValidator.isValidManagerID(managerID)) {
                    System.out.println("Invalid Manager ID. Example: MTLM1234");
                    continue;
                }
                break;
            }

            String office = managerID.substring(0, 3);

            DVRMSInterface server =
                    DVRMSInterfaceHelper.narrow(
                            ncRef.resolve_str("FE")
                    );

            System.out.println("Connected to Highly Available DVRMS (Front End).");

            // ================= MENU LOOP =================
            while (true) {

                System.out.println("\n=== MANAGER MENU ===");
                System.out.println("1. Add Vehicle");
                System.out.println("2. Remove Vehicle");
                System.out.println("3. List Available Vehicles");
                System.out.println("4. Exit");
                System.out.print("Choice: ");

                int choice = sc.nextInt();
                sc.nextLine();

                switch (choice) {

                    // =============== ADD ===============
                    case 1: {

                        System.out.print("Vehicle Type: ");
                        String type = sc.nextLine();

                        String vehicleID;

                        while (true) {
                            System.out.print("Vehicle ID: ");
                            vehicleID = sc.nextLine().toUpperCase();

                            if (!InputValidator.isValidVehicleID(vehicleID)) {
                                System.out.println("Invalid Vehicle ID. Example: MTL1234");
                                continue;
                            }

                            if (!vehicleID.substring(0, 3).equals(office)) {
                                System.out.println("You can only manage vehicles of your own office.");
                                continue;
                            }

                            break;
                        }

                        System.out.print("Vehicle Number: ");
                        String vehicleNumber = sc.nextLine();

                        double price;

                        while (true) {
                            try {
                                System.out.print("Price: $");
                                price = Double.parseDouble(sc.nextLine());

                                if (price <= 0) throw new Exception();
                                break;

                            } catch (Exception e) {
                                System.out.println("Invalid price.");
                            }
                        }

                        String result = server.addVehicle(
                                managerID,
                                vehicleNumber,
                                type,
                                vehicleID,
                                price
                        );

                        System.out.println(result);
                        break;
                    }

                    // =============== REMOVE ===============
                    case 2: {

                        String vehicleID;

                        while (true) {
                            System.out.print("Vehicle ID: ");
                            vehicleID = sc.nextLine().toUpperCase();

                            if (!InputValidator.isValidVehicleID(vehicleID)) {
                                System.out.println("Invalid Vehicle ID. Example: MTL1234");
                                continue;
                            }

                            if (!vehicleID.substring(0, 3).equals(office)) {
                                System.out.println("You can only manage vehicles of your own office.");
                                continue;
                            }

                            break;
                        }

                        String result =
                                server.removeVehicle(managerID, vehicleID);

                        System.out.println(result);
                        break;
                    }

                    // =============== LIST ===============
                    case 3: {

                        String result =
                                server.listAvailableVehicle(managerID);

                        System.out.println(result);
                        break;
                    }

                    // =============== EXIT ===============
                    case 4: {
                        System.out.println("Manager client exiting...");
                        sc.close();
                        System.exit(0);
                        break;
                    }

                    default:
                        System.out.println("Invalid option");
                        break;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}