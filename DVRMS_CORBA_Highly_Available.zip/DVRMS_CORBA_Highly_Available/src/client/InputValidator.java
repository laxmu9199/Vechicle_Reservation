    package client;

    import java.time.LocalDate;
    import java.time.format.DateTimeFormatter;
    import java.time.format.DateTimeParseException;

    public class InputValidator {

        private static final String MANAGER_REGEX =
                "^(MTL|WPG|BNF)M\\d{4}$";

        private static final String CUSTOMER_REGEX =
                "^(MTL|WPG|BNF)U\\d{4}$";

        private static final String VEHICLE_REGEX =
                "^(MTL|WPG|BNF)\\d{4}$";

        private static final DateTimeFormatter FORMATTER =
                DateTimeFormatter.ofPattern("ddMMyyyy");

        // ================= MANAGER =================
        public static boolean isValidManagerID(String id) {
            return id.matches(MANAGER_REGEX);
        }

        // ================= CUSTOMER =================
        public static boolean isValidCustomerID(String id) {
            return id.matches(CUSTOMER_REGEX);
        }

        // ================= VEHICLE =================
        public static boolean isValidVehicleID(String id) {
            return id.matches(VEHICLE_REGEX);
        }

        // ================= DATE =================
        public static boolean isValidDate(String date) {
            try {
                LocalDate.parse(date, FORMATTER);
                return true;
            } catch (DateTimeParseException e) {
                return false;
            }
        }
    }
