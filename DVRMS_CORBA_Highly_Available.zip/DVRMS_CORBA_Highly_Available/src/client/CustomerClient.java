package client;

import java.util.*;
import idl.DVRMS.*;
import org.omg.CORBA.*;
import org.omg.CosNaming.*;
import org.omg.CosNaming.NamingContextExtHelper;

public class CustomerClient {

    public static void main(String[] args) {
        try {

            ORB orb = ORB.init(args, null);

            org.omg.CORBA.Object objRef =
                    orb.resolve_initial_references("NameService");

            NamingContextExt ncRef =
                    NamingContextExtHelper.narrow(objRef);

            Scanner sc = new Scanner(System.in);

            // ================= LOGIN ONCE =================
            String customerID;

            while (true) {
                System.out.print("Enter Customer ID: ");
                customerID = sc.nextLine().toUpperCase();

                if (!InputValidator.isValidCustomerID(customerID)) {
                    System.out.println("Invalid Customer ID. Example: MTLU1234");
                    continue;
                }
                break;
            }

//            String office = customerID.substring(0, 3);

            DVRMSInterface server =
                    DVRMSInterfaceHelper.narrow(
                            ncRef.resolve_str("FE")
                    );

            System.out.println("User: " + customerID + " connected to DVRMS.");

            // ================= MENU LOOP =================
            while (true) {

                System.out.println("\n=== CUSTOMER MENU ===");
                System.out.println("1. Reserve Vehicle");
                System.out.println("2. Cancel Reservation");
                System.out.println("3. Update Reservation");
                System.out.println("4. Find Vehicle");
                System.out.println("5. Exit");
                System.out.println("99. Crash RM2 (DEBUG)");
                System.out.print("Choice: ");

                int choice = sc.nextInt();
                sc.nextLine();

                switch (choice) {

                    // ================= RESERVE =================
                    case 1: {

                        String vehicleID;

                        while (true) {
                            System.out.print("Vehicle ID: ");
                            vehicleID = sc.nextLine().toUpperCase();

                            if (!InputValidator.isValidVehicleID(vehicleID)) {
                                System.out.println("Invalid Vehicle ID. Example: MTL1234");
                                continue;
                            }
                            break;
                        }

                         String start;
                        while (true) {
                            System.out.print("Start Date (ddMMyyyy): ");
                            start = sc.nextLine();

                            if (!InputValidator.isValidDate(start)) {
                                System.out.println("Invalid date. Example: 09022026");
                                continue;
                            }
                            break;
                        }

                        String end;
                        while (true) {
                            System.out.print("End Date (ddMMyyyy): ");
                            end = sc.nextLine();

                            if (!InputValidator.isValidDate(end)) {
                                System.out.println("Invalid date. Example: 09022026");
                                continue;
                            }
                            break;
                        }

                        String result =
                                server.reserveVehicle(customerID, vehicleID, start, end);

                        System.out.println(result);

                        // ===== WAITLIST CONFIRMATION =====
                        if (result.toLowerCase().contains("waitlist")) {

                            System.out.print("Do you want to stay in waitlist? (yes/no): ");
                            String choiceInput = sc.nextLine().trim().toLowerCase();

                            if (choiceInput.equals("no")) {

                                // remove from waitlist
                                String cancelResult =
                                        server.cancelReservation(customerID, vehicleID);

                                System.out.println("Removed from waitlist.");
                                System.out.println(cancelResult);
                            } else {
                                System.out.println("You remain in waitlist.");
                            }
                        }
                        break;
                    }

                    // ================= CANCEL =================
                    case 2: {

                        String vehicleID;

                        while (true) {
                            System.out.print("Vehicle ID: ");
                            vehicleID = sc.nextLine().toUpperCase();

                            if (!InputValidator.isValidVehicleID(vehicleID)) {
                                System.out.println("Invalid Vehicle ID. Example: MTL1234");
                                continue;
                            }
                            break;
                        }

                        String result =
                                server.cancelReservation(customerID, vehicleID);

                        System.out.println(result);
                        break;
                    }

                    // ================= UPDATE =================
                    case 3: {

                        String vehicleID;

                        while (true) {
                            System.out.print("Vehicle ID: ");
                            vehicleID = sc.nextLine().toUpperCase();

                            if (!InputValidator.isValidVehicleID(vehicleID)) {
                                System.out.println("Invalid Vehicle ID. Example: MTL1234");
                                continue;
                            }
                            break;
                        }

                        String newStart;
                        while (true) {
                            System.out.print("New Start Date (ddMMyyyy): ");
                            newStart = sc.nextLine();

                            if (!InputValidator.isValidDate(newStart)) {
                                System.out.println("Invalid date. Example: 09022026");
                                continue;
                            }
                            break;
                        }

                        String newEnd;
                        while (true) {
                            System.out.print("New End Date (ddMMyyyy): ");
                            newEnd = sc.nextLine();

                            if (!InputValidator.isValidDate(newEnd)) {
                                System.out.println("Invalid date. Example: 09022026");
                                continue;
                            }
                            break;
                        }

                        String result =
                                server.updateReservation(customerID, vehicleID, newStart, newEnd);

                        System.out.println(result);
                        break;
                    }

                    // ================= FIND =================
                    case 4: {

                        System.out.print("Vehicle Type (or ALL): ");
                        String type = sc.nextLine();

                        String result =
                                server.findVehicle(customerID, type);

                        System.out.println(result);
                        break;
                    }

                    case 5: {
                        System.out.println("Customer client exiting...");
                        sc.close();
                        System.exit(0);
                        break;
                    }

                    case 99: {
                        String result =
                                server.findVehicle("CRASH_RM2", "ALL");

                        System.out.println("Crash signal sent.");
                        break;
                    }

                    default:
                        System.out.println("Invalid option");
                        break;
                }
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
