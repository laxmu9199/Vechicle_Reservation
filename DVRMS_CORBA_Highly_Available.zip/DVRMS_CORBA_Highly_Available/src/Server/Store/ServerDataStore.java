package Server.Store;

import Server.Models.Reservation;
import Server.Models.Vehicle;

import java.time.LocalDate;
import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

public class ServerDataStore {

    // Server.Models.Vehicle inventory (vehicleID → Server.Models.Vehicle)
    private ConcurrentHashMap<String, Vehicle> vehicles;

    // Customer budgets (customerID → budget)
    private ConcurrentHashMap<String, Double> customerBudget;


    private ConcurrentHashMap<String, Set<String>> customerReservations;


    public ServerDataStore() {
        vehicles = new ConcurrentHashMap<>();
        customerBudget = new ConcurrentHashMap<>();
        customerReservations = new ConcurrentHashMap<>();
    }

    public double getBudget(String customerID) {
        return customerBudget.computeIfAbsent(customerID, k -> 1000.0);
    }

    public void updateBudget(String customerID, double amount) {
        customerBudget.put(customerID, amount);
    }

    // Getter for vehicles map
    public ConcurrentHashMap<String, Vehicle> getVehicles() {
        return vehicles;
    }

    public synchronized String addVehicle(String vehicleID,
                                          String vehicleNumber,
                                          String type,
                                          double price) {

        if (vehicles.containsKey(vehicleID)) {
            return "Vehicle with same ID already exists.";
        }

        Vehicle v = new Vehicle(vehicleID, vehicleNumber, type, price);
        vehicles.put(vehicleID, v);


        return "Vehicle added successfully.";
    }

    public String removeVehicle(String vehicleID) {

        Vehicle vehicle = vehicles.get(vehicleID);

        if (vehicle == null) {
            return "Vehicle with ID " + vehicleID + " does not exist.";
        }

        synchronized (vehicle) {

            // ===== Remove from ACTIVE reservations =====
            for (Reservation r : vehicle.reservations) {

                // Remove vehicle from customer's reserved set
                Set<String> reservedSet = customerReservations.get(r.customerID);
                if (reservedSet != null) {
                    reservedSet.remove(vehicleID);
                }
            }

            // ===== Clear reservations =====
            vehicle.reservations.clear();

            // ===== Clear waitlist =====
            vehicle.waitlist.clear();

            // ===== Remove vehicle from store =====
            vehicles.remove(vehicleID);
        }

        return "Vehicle " + vehicleID +
                " removed successfully. All reservations and waitlists cleared.";
    }


    /**
     * Lists all available vehicles in the server.
     *
     * @return a formatted string containing vehicle details
     */
    public String listVehicles() {

        if (vehicles.isEmpty()) {
            return "No vehicles available.";
        }

        StringBuilder sb = new StringBuilder();

        sb.append("-----------------------------------------------------------------------------\n");

        sb.append(String.format(
                "%-10s %-10s %-10s %-15s %-15s %-10s\n",
                "VehicleID", "Type", "Number",
                "Status", "Waitlist", "Price"));

        sb.append("-----------------------------------------------------------------------------\n");

        for (Vehicle v : vehicles.values()) {

            // ===== Status Column =====
            String status;

            if (v.reservations.isEmpty()) {
                status = "Available";
            } else {
                status = v.reservations.size() + " Reserved";
            }

            // ===== Waitlist Count =====
            String waitInfo = String.valueOf(v.waitlist.size());

            sb.append(String.format(
                    "%-10s %-10s %-10s %-15s %-15s $%-8.2f\n",
                    v.vehicleID,
                    v.vehicleType,
                    v.vehicleNumber,
                    status,
                    waitInfo,
                    v.price));
        }

        return sb.toString();
    }




    public synchronized String reserve(String customerID,
                                       String vehicleID,
                                       LocalDate startDate,
                                       LocalDate endDate) {

//        System.out.println("DEBUGGING");
//        System.out.println("CustomerID = " + customerID);
//        System.out.println("VehicleID Requested = [" + vehicleID + "]");
//        System.out.println("Store Keys = " + vehicles.keySet());

        Vehicle vehicle = vehicles.get(vehicleID);

        if (vehicle == null) {
            return "Vehicle " + vehicleID + " does not exist.";
        }

        if (endDate.isBefore(startDate)) {
            return "Invalid reservation dates.";
        }

        // Checking if customer has already reserved the vehicle
        for (Reservation r : vehicle.reservations) {
            if (r.customerID.equals(customerID)) {
                return "Vehicle already reserved by you.";
            }
        }


        String customerOffice = customerID.substring(0, 3);
        String vehicleOffice = vehicleID.substring(0, 3);

        Set<String> reservedSet =
                customerReservations.computeIfAbsent(
                        customerID,
                        k -> new HashSet<>()
                );

        if (!customerOffice.equals(vehicleOffice)) {
            for (String reservedVehicleID : reservedSet) {
                if (reservedVehicleID.startsWith(vehicleOffice)) {
                    return "You can reserve only ONE vehicle from office " + vehicleOffice;
                }
            }
        }

//        double localUsed = getUsedBudget(customerID);
//
//        if (localUsed + vehicle.price > 1000) {
//            return "Insufficient budget. Total budget limit is $1000.";
//        }


        boolean conflict = false;

        for (Reservation r : vehicle.reservations) {

            boolean overlap =
                    !(endDate.isBefore(r.startDate) ||
                            startDate.isAfter(r.endDate));

            if (overlap) {
                conflict = true;
                break;
            }
        }

        if (!conflict) {

            Reservation reservation =
                    new Reservation(customerID, startDate, endDate);

            vehicle.reservations.add(reservation);

            reservedSet.add(vehicleID);

            return "Reservation successful for vehicle " + vehicleID;
        }

// If conflict → add to waitlist
        Reservation waitRequest =
                new Reservation(customerID, startDate, endDate);

        vehicle.waitlist.add(waitRequest);
        return "Vehicle not available for selected dates. Added to waitlist.";
    }



    public synchronized String cancel(String customerID, String vehicleID) {

        Vehicle vehicle = vehicles.get(vehicleID);

        if (vehicle == null) {
            return "Vehicle does not exist.";
        }

        // Check ACTIVE reservations
        Reservation target = null;

        for (Reservation r : vehicle.reservations) {
            if (r.customerID.equals(customerID)) {
                target = r;
                break;
            }
        }

        if (target != null) {

            vehicle.reservations.remove(target);

            Set<String> reservedSet = customerReservations.get(customerID);
            if (reservedSet != null) {
                reservedSet.remove(vehicleID);
            }

            // After removing active reservation,
            // try assigning from waitlist
            assignFromWaitlist(vehicle);

            return "Active reservation cancelled successfully.";
        }

        // Check WAITLIST
        Reservation waitTarget = null;

        for (Reservation r : vehicle.waitlist) {
            if (r.customerID.equals(customerID)) {
                waitTarget = r;
                break;
            }
        }

        if (waitTarget != null) {
            vehicle.waitlist.remove(waitTarget);
            return "Reservation removed from waiting list successfully.";
        }

        return "Reservation not found.";
    }




    private void assignFromWaitlist(Vehicle vehicle) {

        while (!vehicle.waitlist.isEmpty()) {

            Reservation nextRequest = vehicle.waitlist.peek();

            boolean conflict = false;

            for (Reservation r : vehicle.reservations) {

                boolean overlap =
                        !(nextRequest.endDate.isBefore(r.startDate) ||
                                nextRequest.startDate.isAfter(r.endDate));

                if (overlap) {
                    conflict = true;
                    break;
                }
            }

            if (conflict) {
                break;
            }

//            double localUsed = getUsedBudget(nextRequest.customerID);
//
//            if (localUsed + vehicle.price > 1000) {
//                vehicle.waitlist.poll();
//                continue;
//            }

            vehicle.waitlist.poll();
            vehicle.reservations.add(nextRequest);

            customerReservations
                    .computeIfAbsent(nextRequest.customerID, k -> new HashSet<>())
                    .add(vehicle.vehicleID);

            break;
        }
    }




    public synchronized String update(String customerID,
                                      String vehicleID,
                                      LocalDate newStart,
                                      LocalDate newEnd) {

        Vehicle vehicle = vehicles.get(vehicleID);
        if (vehicle == null)
            return "Vehicle " + vehicleID + " does not exist.";

        if (newEnd.isBefore(newStart))
            return "Invalid reservation dates.";

        // ===== 1. CHECK ACTIVE RESERVATION =====
        Reservation activeTarget = null;

        for (Reservation r : vehicle.reservations) {
            if (r.customerID.equals(customerID)) {
                activeTarget = r;
                break;
            }
        }

        if (activeTarget != null) {

            // Check conflict with others
            for (Reservation r : vehicle.reservations) {

                if (r == activeTarget) continue;

                boolean overlap =
                        !(newEnd.isBefore(r.startDate) ||
                                newStart.isAfter(r.endDate));

                if (overlap)
                    return "Updated dates conflict with another reservation.";
            }

            // Update active reservation
            activeTarget.startDate = newStart;
            activeTarget.endDate = newEnd;

            // After updating, re-check waitlist
            assignFromWaitlist(vehicle);

            return "Reservation updated successfully.";
        }

        // ===== 2. CHECK WAITLIST =====
        Reservation waitTarget = null;

        for (Reservation r : vehicle.waitlist) {
            if (r.customerID.equals(customerID)) {
                waitTarget = r;
                break;
            }
        }

        if (waitTarget != null) {

            // Check if new dates conflict with active reservations
            boolean conflict = false;

            for (Reservation r : vehicle.reservations) {

                boolean overlap =
                        !(newEnd.isBefore(r.startDate) ||
                                newStart.isAfter(r.endDate));

                if (overlap) {
                    conflict = true;
                    break;
                }
            }

            if (!conflict) {

                // Remove from waitlist
                vehicle.waitlist.remove(waitTarget);

                // Move to active reservation
                waitTarget.startDate = newStart;
                waitTarget.endDate = newEnd;

                vehicle.reservations.add(waitTarget);

                return "Waitlisted reservation promoted to active reservation, Reservation Successful!";
            }

            // Still conflict → just update waitlist dates
            waitTarget.startDate = newStart;
            waitTarget.endDate = newEnd;

            return "Waitlist reservation updated. Still in waiting list.";
        }

        return "Reservation not found.";
    }

    public synchronized String handleFind(String vehicleType, String customerID) {

        StringBuilder sb = new StringBuilder();

        for (Vehicle v : vehicles.values()) {

            if (vehicleType.equalsIgnoreCase("ALL") ||
                    v.vehicleType.equalsIgnoreCase(vehicleType)) {

                String availability =
                        v.reservations.isEmpty() ? "Available" : "Reserved";

                String yourStatus = "-";

                for (Reservation r : v.reservations) {
                    if (r.customerID.equals(customerID)) {
                        yourStatus = "Reserved by you";
                        break;
                    }
                }

                if (yourStatus.equals("-")) {
                    for (Reservation r : v.waitlist) {
                        if (r.customerID.equals(customerID)) {
                            yourStatus = "Waitlisted by you";
                            break;
                        }
                    }
                }

                sb.append(String.format(
                        "%s;%s;%s;%s;%.2f\n",
                        v.vehicleID,
                        v.vehicleType,
                        availability,
                        yourStatus,
                        v.price));
            }
        }

        return sb.toString();
    }


    public synchronized double getUsedBudget(String customerID) {

        double total = 0;

        for (Vehicle v : vehicles.values()) {
            for (Reservation r : v.reservations) {
                if (r.customerID.equals(customerID)) {
                    total += v.price;
                }
            }
        }

        return total;
    }


    public synchronized boolean canUpdate(String customerID,
                                          String vehicleID,
                                          LocalDate newStart,
                                          LocalDate newEnd) {

        Vehicle vehicle = vehicles.get(vehicleID);
        if (vehicle == null) return false;

        if (newEnd.isBefore(newStart)) return false;

        // ---- CHECK ACTIVE RESERVATIONS ----
        for (Reservation r : vehicle.reservations) {
            if (r.customerID.equals(customerID)) {

                // Check conflict with others
                for (Reservation other : vehicle.reservations) {

                    if (other == r) continue;

                    boolean overlap =
                            !(newEnd.isBefore(other.startDate) ||
                                    newStart.isAfter(other.endDate));

                    if (overlap) return false;
                }

                return true; // Active reservation can update
            }
        }

        // ---- CHECK WAITLIST ----
        for (Reservation r : vehicle.waitlist) {
            if (r.customerID.equals(customerID)) {
                return true; // Waitlist entry exists → allow update attempt
            }
        }

        return false;
    }


}
