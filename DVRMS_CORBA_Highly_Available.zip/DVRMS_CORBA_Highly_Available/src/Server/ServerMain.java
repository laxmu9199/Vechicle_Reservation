package Server;

import idl.DVRMS.DVRMSInterface;
import idl.DVRMS.DVRMSInterfaceHelper;
import org.omg.CORBA.*;
import org.omg.CosNaming.*;
import org.omg.PortableServer.*;

public class ServerMain {

    public static void main(String args[]) {

        try {

            ORB orb = ORB.init(args, null);

            POA rootpoa =
                    POAHelper.narrow(orb.resolve_initial_references("RootPOA"));

            rootpoa.the_POAManager().activate();

            registerOffice("MTL", orb, rootpoa);
            registerOffice("WPG", orb, rootpoa);
            registerOffice("BNF", orb, rootpoa);

            System.out.println("All CORBA servers ready...");

            orb.run();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void registerOffice(String office,
                                       ORB orb,
                                       POA rootpoa) throws Exception {

        OfficeServant servant = new OfficeServant(office);

        org.omg.CORBA.Object ref =
                rootpoa.servant_to_reference(servant);

        DVRMSInterface href =
                DVRMSInterfaceHelper.narrow(ref);

        org.omg.CORBA.Object objRef =
                orb.resolve_initial_references("NameService");

        NamingContextExt ncRef =
                NamingContextExtHelper.narrow(objRef);

        NameComponent path[] =
                ncRef.to_name(office);

        ncRef.rebind(path, href);

        System.out.println(office + " CORBA Server ready...");
    }
}