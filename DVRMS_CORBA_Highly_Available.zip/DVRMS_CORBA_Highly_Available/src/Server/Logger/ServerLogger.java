package Server.Logger;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class ServerLogger {


    public static synchronized void log(String office, String action, String userID, String targetID) {
        // File name per office
        String filename = office + "_ServerLog.txt";
        // Format current date and time
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss"));

        // Constructing log message
        String logMessage = String.format("[%s] Action: %s, UserID: %s, TargetID: %s", timestamp, action, userID, targetID);

        // Writing to file
        try (FileWriter fw = new FileWriter(filename, true);
             PrintWriter pw = new PrintWriter(fw)) {
            pw.println(logMessage);
        } catch (IOException e) {
            System.err.println("Error writing log: " + e.getMessage());
        }
    }
}
