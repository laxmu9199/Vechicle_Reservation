package Server;

import Server.Logger.ServerLogger;
import Server.Models.Vehicle;
import Server.Store.ServerDataStore;
//import Server.UDP.UDPServer;
import idl.DVRMS.DVRMSInterfacePOA;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class OfficeServant extends DVRMSInterfacePOA {

    private final String office;
    private final ServerDataStore store;

    private static final DateTimeFormatter FORMATTER =
            DateTimeFormatter.ofPattern("ddMMyyyy");

    public OfficeServant(String office) {

        this.office = office;
        this.store = new ServerDataStore();

//        int udpPort = getUDPPort(office);
//        new Thread(new UDPServer(udpPort, store)).start();
    }

    private int getUDPPort(String office) {
        switch (office) {
            case "MTL": return 6000;
            case "WPG": return 6001;
            case "BNF": return 6002;
            default: throw new IllegalArgumentException("Invalid office");
        }
    }

    @Override
    public String addVehicle(String managerID,
                             String number,
                             String type,
                             String vehicleID,
                             double price) {

        if (!managerID.startsWith(office + "M"))
            return "Unauthorized manager";

        ServerLogger.log(office, "ADD VEHICLE", managerID, vehicleID);

        return store.addVehicle(vehicleID, number, type, price);
    }

    @Override
    public String removeVehicle(String managerID, String vehicleID) {

        if (!managerID.startsWith(office + "M"))
            return "Unauthorized manager";

        ServerLogger.log(office, "REMOVE VEHICLE", managerID, vehicleID);

        return store.removeVehicle(vehicleID);
    }

    @Override
    public String listAvailableVehicle(String managerID) {
        return store.listVehicles();
    }

    @Override
    public String reserveVehicle(String customerID,
                                 String vehicleID,
                                 String start,
                                 String end) {

        String result;

        result = store.reserve(
                customerID,
                vehicleID,
                LocalDate.parse(start, FORMATTER),
                LocalDate.parse(end, FORMATTER)
        );

        ServerLogger.log(
                vehicleID.substring(0, 3),
                "RESERVE VEHICLE",
                customerID,
                vehicleID
        );

//        return appendRemainingBudget(customerID, result);
    return result;
    }

    @Override
    public String cancelReservation(String customerID, String vehicleID) {

        String result = store.cancel(customerID, vehicleID);

        ServerLogger.log(
                vehicleID.substring(0, 3),
                "CANCEL RESERVATION",
                customerID,
                vehicleID
        );

//        return appendRemainingBudget(customerID, result);
    return result;
    }

    @Override
    public String updateReservation(String customerID,
                                    String vehicleID,
                                    String ns,
                                    String ne) {

        String result = store.update(
                customerID,
                vehicleID,
                LocalDate.parse(ns, FORMATTER),
                LocalDate.parse(ne, FORMATTER)
        );

        ServerLogger.log(
                vehicleID.substring(0, 3),
                "UPDATE RESERVATION",
                customerID,
                vehicleID
        );

        return result;
    }

    @Override
    public String findVehicle(String customerID, String type) {
        return store.handleFind(type, customerID);
    }


    public ServerDataStore getStore() {
        return store;
    }


    public double getUsedBudget(String customerID) {
        return store.getUsedBudget(customerID);
    }

    public double getVehiclePrice(String vehicleID) {

        Vehicle v = store.getVehicles().get(vehicleID);

        if (v == null) return 0;

        return v.price;
    }
//    private String appendRemainingBudget(String customerID, String message) {
//
//        double localUsed = store.getUsedBudget(customerID);
//
//        double used = store.getUsedBudget(customerID);
//        double remaining = 1000 - used;
//
//        return message + "\nRemaining Budget: $" + String.format("%.2f", remaining);
//    }
}