package Server.Models;

import java.time.LocalDate;

public class Reservation {
    public String customerID;

    public LocalDate startDate;
    public LocalDate endDate;

    public Reservation(String customerID,
                       LocalDate startDate,
                       LocalDate endDate) {
        this.customerID = customerID;
        this.startDate = startDate;
        this.endDate = endDate;
    }
}
