package Server.Models;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

public class Vehicle {
    public String vehicleID;
    public String vehicleType;
    public String vehicleNumber;
    public double price;

    public List<Reservation> reservations;
    public Queue<Reservation> waitlist;

    public Vehicle(String vehicleID,
                   String vehicleNumber,
                   String vehicleType,
                   double price) {

        this.vehicleID = vehicleID;
        this.vehicleNumber = vehicleNumber;
        this.vehicleType = vehicleType;
        this.price = price;

        this.reservations = new ArrayList<>();
        this.waitlist = new LinkedList<>();
    }
}
