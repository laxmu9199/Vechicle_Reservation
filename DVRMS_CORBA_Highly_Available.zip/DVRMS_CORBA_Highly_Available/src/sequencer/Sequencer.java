package sequencer;

import java.net.*;

public class Sequencer {

    private static int sequenceNumber = 0;

    public static void main(String[] args) {

        try (DatagramSocket socket = new DatagramSocket(7000)) {

            byte[] buffer = new byte[1024];

            System.out.println("Sequencer is running on port 7000...");

            while (true) {

                DatagramPacket request =
                        new DatagramPacket(buffer, buffer.length);

                socket.receive(request);

                String message =
                        new String(request.getData(), 0, request.getLength());

                // ===== ADD GLOBAL SEQUENCE NUMBER =====
                sequenceNumber++;

                String orderedMessage =
                        sequenceNumber + ";" + message;

                System.out.println("Sequenced: " + orderedMessage);

                // ===== MULTICAST TO ALL RMs =====
                multicastToRMs(orderedMessage);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void multicastToRMs(String message) throws Exception {

//        InetAddress host = InetAddress.getByName("localhost");
//
//        int[] RM_PORTS = {8000, 8001, 8002}; // one per RM
//
//        for (int port : RM_PORTS) {
//
//            System.out.println("Sending to RM port: " + port);
//
//            DatagramSocket socket = new DatagramSocket();
//
//            byte[] data = message.getBytes();
//
//            DatagramPacket packet =
//                    new DatagramPacket(data, data.length, host, port);
//
//            socket.send(packet);
//            socket.close();
//        }


        String[] RM_IPS = {
                "10.230.233.161", // RM1
                "10.230.233.161", // RM2
                "10.230.233.216"  // RM3
        };

        int[] RM_PORTS = {8000, 8001, 8002};

        for (int i = 0; i < RM_PORTS.length; i++) {
            DatagramSocket socket = new DatagramSocket();

            InetAddress host = InetAddress.getByName(RM_IPS[i]);

            byte[] data = message.getBytes();

            DatagramPacket packet =
                    new DatagramPacket(data, data.length, host, RM_PORTS[i]);

            socket.send(packet);
            socket.close();
        }
    }
}