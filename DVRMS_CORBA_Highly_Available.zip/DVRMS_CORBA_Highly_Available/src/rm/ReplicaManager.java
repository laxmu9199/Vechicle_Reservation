package rm;

import Server.OfficeServant;

import java.net.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class ReplicaManager {


    private Map<String, OfficeServant> servers;
    private final int port;
    private final String replicaName;
    private boolean replicaAlive = true;

    private boolean isCrashed = false;

    public ReplicaManager(String replicaName, int port) {
        this.replicaName = replicaName;
        this.port = port;

        initializeServers();

        new Thread(this::startListening).start();

        System.out.println(replicaName + " started on port " + port);
    }

    // ================= INIT =================
    private void initializeServers() {
        servers = new HashMap<>();

        servers.put("MTL", new OfficeServant("MTL"));
        servers.put("WPG", new OfficeServant("WPG"));
        servers.put("BNF", new OfficeServant("BNF"));
    }

    // ================= LISTENER =================
    private void startListening() {

        try (DatagramSocket socket = new DatagramSocket(port)) {

            byte[] buffer = new byte[2048];

            while (true) {

                if (isCrashed) {
                    try {
                        Thread.sleep(30000); // simulate downtime
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }

                    System.out.println(replicaName + " RECOVERING...");
                    restartReplica();
                    isCrashed = false;
                }


                DatagramPacket request =
                        new DatagramPacket(buffer, buffer.length);

                socket.receive(request);

                String message =
                        new String(request.getData(), 0, request.getLength());

                System.out.println(replicaName + " received: " + message);

                String response;

                try {

                    if (!replicaAlive) {
                        restartReplica();
                    }

                    response = processRequest(message);

                    //Debug
                    System.out.println(replicaName + " response: " + response);

                } catch (Exception e) {

                    System.out.println(replicaName + " detected crash!");

                    replicaAlive = false;

                    restartReplica();

                    response = "Replica restarted. Please retry request.";
                }

                sendToFE(response);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ================= REQUEST PROCESSING =================
    private String processRequest(String message) {


        if (replicaName.equals("RM2") && new Random().nextInt(3) == 0) {
            return "Random Fault from RM2";
        }

        // ===== DELIBERATE CRASH =====
        if (message.contains("CRASH_" + replicaName)) {
            System.out.println(replicaName + " CRASHED deliberately!");
            isCrashed = true;
            throw new RuntimeException("Simulated Crash");
        }

        String[] parts = message.split(";");

        String operation = parts[2];

        try {

            switch (operation) {

                case "ADD": {
                    String managerID = parts[3];
                    String number = parts[4];
                    String type = parts[5];
                    String vehicleID = parts[6];
                    double price = Double.parseDouble(parts[7]);

                    String office = vehicleID.substring(0, 3);

                    return servers.get(office)
                            .addVehicle(managerID, number, type, vehicleID, price);
                }

                case "REMOVE": {
                    String managerID = parts[3];
                    String vehicleID = parts[4];

                    String office = vehicleID.substring(0, 3);

                    return servers.get(office)
                            .removeVehicle(managerID, vehicleID);
                }

                case "LIST": {

                    String managerID = parts[3];

                    // Extract office from manager ID
                    String office = managerID.substring(0, 3);

                    // Return ONLY that office's data
                    return servers.get(office).listAvailableVehicle(managerID);
                }

                case "RESERVE": {

                    String customerID = parts[3];
                    String vehicleID = parts[4];
                    String start = parts[5];
                    String end = parts[6];

                    String office = vehicleID.substring(0, 3);

                    //  GLOBAL BUDGET CALCULATION
                    double totalUsed = 0;

                    for (OfficeServant server : servers.values()) {
                        totalUsed += server.getUsedBudget(customerID);
                    }

                    double vehiclePrice =
                            servers.get(office)
                                    .getVehiclePrice(vehicleID);

                    if (totalUsed + vehiclePrice > 1000) {
                        return "Insufficient budget. Total budget limit is $1000.";
                    }

                    String result = servers.get(office)
                            .reserveVehicle(customerID, vehicleID, start, end);

                    return appendRemainingBudget(customerID, result);
                }

                case "CANCEL": {
                    String customerID = parts[3];
                    String vehicleID = parts[4];

                    String office = vehicleID.substring(0, 3);

                    String result = servers.get(office)
                            .cancelReservation(customerID, vehicleID);

                    return appendRemainingBudget(customerID, result);
                }

                case "UPDATE": {
                    String customerID = parts[3];
                    String vehicleID = parts[4];
                    String ns = parts[5];
                    String ne = parts[6];

                    String office = vehicleID.substring(0, 3);

                    return servers.get(office)
                            .updateReservation(customerID, vehicleID, ns, ne);
                }

                case "FIND": {
                    String customerID = parts[3];
                    String type = parts[4];

                    StringBuilder result = new StringBuilder();

                    for (OfficeServant server : servers.values()) {
                        result.append(
                                server.listAvailableVehicle(customerID)
                        ).append("\n");
                    }

                    return result.toString();
                }

                default:
                    return "Invalid operation";

            }

        } catch (Exception e) {
            return "RM Error: " + e.getMessage();
        }

    }


    private String appendRemainingBudget(String customerID, String message) {

        double totalUsed = 0;

        for (OfficeServant server : servers.values()) {
            totalUsed += server.getUsedBudget(customerID);
        }

        double remaining = 1000 - totalUsed;

        return message + "\nRemaining Budget: $" + String.format("%.2f", remaining);
    }


    // ================= SEND RESPONSE =================
    private void sendToFE(String response) {

        try {
            DatagramSocket socket = new DatagramSocket();

//            InetAddress host = InetAddress.getByName("localhost");

            InetAddress host = InetAddress.getByName("10.230.233.241");

            int FE_PORT = 9000;

            byte[] data = response.getBytes();

            DatagramPacket packet =
                    new DatagramPacket(data, data.length, host, FE_PORT);

            socket.send(packet);
            socket.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ================= RESTART =================
    private void restartReplica() {

        try {
            System.out.println(replicaName + " restarting ALL servers...");

            initializeServers();  //  FULL RESET

            replicaAlive = true;

            System.out.println(replicaName + " recovery complete.");

        } catch (Exception e) {
            System.out.println(replicaName + " restart failed!");
        }
    }
}