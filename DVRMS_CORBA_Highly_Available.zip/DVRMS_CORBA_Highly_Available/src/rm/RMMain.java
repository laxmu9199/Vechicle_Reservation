package rm;

public class RMMain {

    public static void main(String[] args) {

        if (args.length < 2) {
            System.out.println("Usage: RMMain <RM_NAME> <PORT>");
            return;
        }

        String rmName = args[0];
        int port = Integer.parseInt(args[1]);

        new ReplicaManager(rmName, port);

        System.out.println(rmName + " is running...");
    }
}