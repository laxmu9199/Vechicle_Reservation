package FrontEnd;

public enum SystemMode {
    HA,
    SFT
}