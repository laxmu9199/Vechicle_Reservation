package FrontEnd;

import idl.DVRMS.*;
import org.omg.CORBA.*;

import java.net.*;
import java.util.*;

public class FrontEndImpl extends DVRMSInterfacePOA {

    private DatagramSocket receiveSocket = null;

    private static int requestCounter = 0;

    private SystemMode mode;

    public FrontEndImpl(SystemMode mode) {
        this.mode = mode;
        try {
            receiveSocket = new DatagramSocket(9000);
            receiveSocket.setSoTimeout(3000);
            System.out.println("FE listening on port 9000...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    private synchronized int getRequestID() {
        return ++requestCounter;
    }

    private String sendToSequencer(String operation, String... params) {

        DatagramSocket sendSocket = null;


        try {
            int requestID = getRequestID();

            // Use one socket for sending
            sendSocket = new DatagramSocket();

            // ===== BUILD MESSAGE =====
            StringBuilder message = new StringBuilder();
            message.append(requestID).append(";").append(operation);

            for (String p : params) {
                message.append(";").append(p);
            }

            byte[] data = message.toString().getBytes();

//            InetAddress host = InetAddress.getByName("localhost");

            InetAddress host = InetAddress.getByName("10.230.233.241");

            // ===== SEND TO SEQUENCER =====
            DatagramPacket request =
                    new DatagramPacket(data, data.length, host, 7000);

            sendSocket.send(request);

            // ===== RECEIVE RESPONSES FROM RM =====
            receiveSocket.setSoTimeout(3000);

            List<String> responses = new ArrayList<>();

            long startTime = System.currentTimeMillis();
            long timeout = 3000; // 3 seconds

            while (System.currentTimeMillis() - startTime < timeout) {

                try {
                    byte[] buffer = new byte[1024];
                    DatagramPacket response =
                            new DatagramPacket(buffer, buffer.length);

                    receiveSocket.receive(response);

                    String res =
                            new String(response.getData(), 0, response.getLength());

                    System.out.println("FE received: " + res);

                    responses.add(res);

                } catch (SocketTimeoutException e) {
                    break; // no more responses
                }
            }

// ===== RESPONSE SELECTION =====

            if (responses.isEmpty()) {
                return "All replicas failed or no response received.";
            }

            // Return Majority voting
            if (mode == SystemMode.HA) {
                return majorityVoting(responses);
            } else {
                return faultTolerance(responses);
            }

        } catch (SocketTimeoutException e) {
            return "Request timeout. Some replicas may have failed.";
        } catch (Exception e) {
            return "FE Error: " + e.getMessage();
        } finally {
            if (sendSocket != null) sendSocket.close();
//            if (receiveSocket != null) receiveSocket.close();
        }
    }

    private String majorityVoting(List<String> responses) {

        Map<String, Integer> countMap = new HashMap<>();

        for (String r : responses) {
            countMap.put(r, countMap.getOrDefault(r, 0) + 1);
        }

        String best = null;
        int max = 0;

        for (Map.Entry<String, Integer> entry : countMap.entrySet()) {
            if (entry.getValue() > max) {
                max = entry.getValue();
                best = entry.getKey();
            }
        }

        return best;
    }

    private String faultTolerance(List<String> responses) {

        Map<String, Integer> countMap = new HashMap<>();

        for (String r : responses) {
            countMap.put(r, countMap.getOrDefault(r, 0) + 1);
        }

        String correct = null;
        int max = 0;

        for (Map.Entry<String, Integer> entry : countMap.entrySet()) {
            if (entry.getValue() > max) {
                max = entry.getValue();
                correct = entry.getKey();
            }
        }

        // Detect faulty replicas
        for (String r : responses) {
            if (!r.equals(correct)) {
                System.out.println("Faulty response detected: " + r);
            }
        }

        return correct;
    }



    // ================= METHODS =================

    @Override
    public String addVehicle(String managerID, String number, String type, String vehicleID, double price) {
        return sendToSequencer("ADD", managerID, number, type, vehicleID, String.valueOf(price));
    }

    @Override
    public String removeVehicle(String managerID, String vehicleID) {
        return sendToSequencer("REMOVE", managerID, vehicleID);
    }

    @Override
    public String listAvailableVehicle(String managerID) {
        return sendToSequencer("LIST", managerID);
    }

    @Override
    public String reserveVehicle(String customerID, String vehicleID, String start, String end) {
        return sendToSequencer("RESERVE", customerID, vehicleID, start, end);
    }

    @Override
    public String updateReservation(String customerID, String vehicleID, String ns, String ne) {
        return sendToSequencer("UPDATE", customerID, vehicleID, ns, ne);
    }

    @Override
    public String cancelReservation(String customerID, String vehicleID) {
        return sendToSequencer("CANCEL", customerID, vehicleID);
    }

    @Override
    public String findVehicle(String customerID, String type) {
        return sendToSequencer("FIND", customerID, type);
    }
}