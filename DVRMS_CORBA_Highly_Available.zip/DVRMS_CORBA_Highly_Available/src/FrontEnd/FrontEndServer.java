package FrontEnd;

import idl.DVRMS.*;
import org.omg.CORBA.*;
import org.omg.PortableServer.*;
import org.omg.CosNaming.*;
import java.util.*;

public class FrontEndServer {

    public static void main(String[] args) {

        try {


//            java.util.Properties props = new java.util.Properties();
//            props.put("com.sun.CORBA.codegen.UseReflectiveCopyFalse", "true");
//            props.put("com.sun.CORBA.ORBServerHost", "10.123.247.161");  // <-- your IP
//            props.put("com.sun.CORBA.ORBInitialHost", "localhost");
//            props.put("com.sun.CORBA.ORBInitialPort", "1050");

            ORB orb = ORB.init(args, null);

            POA rootpoa =
                    POAHelper.narrow(orb.resolve_initial_references("RootPOA"));

            rootpoa.the_POAManager().activate();



            Scanner sc = new Scanner(System.in);

            System.out.println("Select Mode:");
            System.out.println("1. High Availability");
            System.out.println("2. Software Fault Tolerance");

            int choice = sc.nextInt();

            SystemMode mode;

            if (choice == 1) {
                mode = SystemMode.HA;
                System.out.println("Running in HIGH AVAILABILITY mode");
            } else {
                mode = SystemMode.SFT;
                System.out.println("Running in SOFTWARE FAULT TOLERANCE mode");
            }


            // ===== CREATE FE =====
            FrontEndImpl fe = new FrontEndImpl(mode);

            org.omg.CORBA.Object ref =
                    rootpoa.servant_to_reference(fe);

            DVRMSInterface href =
                    DVRMSInterfaceHelper.narrow(ref);

            // ===== REGISTER IN NAMING SERVICE =====
            System.out.println("Before NameService...");

            org.omg.CORBA.Object objRef =
                    orb.resolve_initial_references("NameService");

            System.out.println("After NameService...");

            NamingContextExt ncRef =
                    NamingContextExtHelper.narrow(objRef);

            NameComponent path[] =
                    ncRef.to_name("FE");

            ncRef.rebind(path, href);

            System.out.println("FE REGISTERED SUCCESSFULLY");


            org.omg.CORBA.Object test = ncRef.resolve_str("FE");
            System.out.println("FE RESOLVED LOCALLY");


            System.out.println("Front End ready...");

            orb.run();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}